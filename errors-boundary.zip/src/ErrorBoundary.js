import React, { Component } from 'react'
import Error from "./Error";
export default class ErrorBoundary extends Component {

     reloadBtnOnClick = () => window.location.reload()

     render() { return (<div><Error reloadBtnOnClick={this.reloadBtnOnClick} /></div>) }
}
