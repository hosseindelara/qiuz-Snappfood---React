import React, { PureComponent } from 'react';
import './App.css';
import Form from "./Form";
import ErrorBoundary from "./ErrorBoundary";
class App extends PureComponent {

  constructor(props) {
    super(props);
    this.state = {
      person: {
        year: ''
      },
      error: ''
    }
  }

  componentDidCatch(error, errorInfo) { this.setState({ error: true }) }


  handleChange = e => this.setState({ person: { year: e.target.value }, })

  render() {
    if (this.state.error) {
      return (
        <div className="App">
          <header className="App-header">
            <ErrorBoundary />
          </header>
        </div>
      )
    }
    return (
      <div className="App">
        <header className="App-header">
          <Form person={this.state.person} handleChange={this.handleChange} />
        </header>
      </div>
    );
  }
}

export default App;
